gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.forEachIndex3 = 0;

gdjs.Game_32SceneCode.forEachObjects3 = [];

gdjs.Game_32SceneCode.forEachTemporary3 = null;

gdjs.Game_32SceneCode.forEachTotalCount3 = 0;

gdjs.Game_32SceneCode.GDEnergyTextObjects1= [];
gdjs.Game_32SceneCode.GDEnergyTextObjects2= [];
gdjs.Game_32SceneCode.GDEnergyTextObjects3= [];
gdjs.Game_32SceneCode.GDEnergyTextObjects4= [];
gdjs.Game_32SceneCode.GDEnergyTextObjects5= [];
gdjs.Game_32SceneCode.GDEnergyBarObjects1= [];
gdjs.Game_32SceneCode.GDEnergyBarObjects2= [];
gdjs.Game_32SceneCode.GDEnergyBarObjects3= [];
gdjs.Game_32SceneCode.GDEnergyBarObjects4= [];
gdjs.Game_32SceneCode.GDEnergyBarObjects5= [];
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects1= [];
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects2= [];
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects3= [];
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects4= [];
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects5= [];
gdjs.Game_32SceneCode.GDLevelProgressObjects1= [];
gdjs.Game_32SceneCode.GDLevelProgressObjects2= [];
gdjs.Game_32SceneCode.GDLevelProgressObjects3= [];
gdjs.Game_32SceneCode.GDLevelProgressObjects4= [];
gdjs.Game_32SceneCode.GDLevelProgressObjects5= [];
gdjs.Game_32SceneCode.GDMergeItemObjects1= [];
gdjs.Game_32SceneCode.GDMergeItemObjects2= [];
gdjs.Game_32SceneCode.GDMergeItemObjects3= [];
gdjs.Game_32SceneCode.GDMergeItemObjects4= [];
gdjs.Game_32SceneCode.GDMergeItemObjects5= [];
gdjs.Game_32SceneCode.GDProducerObjects1= [];
gdjs.Game_32SceneCode.GDProducerObjects2= [];
gdjs.Game_32SceneCode.GDProducerObjects3= [];
gdjs.Game_32SceneCode.GDProducerObjects4= [];
gdjs.Game_32SceneCode.GDProducerObjects5= [];


gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() >= runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
if (isConditionTrue_0) {
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).setNumber(Math.floor(gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() / runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber()));
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(Math.min(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() + gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber()));
}
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() + gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber() * runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
}

}


};gdjs.Game_32SceneCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Game_32SceneCode.GDMergeItemObjects1, gdjs.Game_32SceneCode.GDMergeItemObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getX() == 64 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getY() == 128 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMergeItemObjects2 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects2[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
}

}


{

gdjs.copyArray(gdjs.Game_32SceneCode.GDMergeItemObjects1, gdjs.Game_32SceneCode.GDMergeItemObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getX() == 192 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getY() == 128 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMergeItemObjects2 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects2[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
}

}


{

/* Reuse gdjs.Game_32SceneCode.GDMergeItemObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getX() == 128 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects1[k] = gdjs.Game_32SceneCode.GDMergeItemObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getY() == 128 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects1[k] = gdjs.Game_32SceneCode.GDMergeItemObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMergeItemObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getVariables().getFromIndex(2)).setNumber(2);
}
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects1Objects = Hashtable.newFrom({"MergeItem": gdjs.Game_32SceneCode.GDMergeItemObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects2Objects = Hashtable.newFrom({"MergeItem": gdjs.Game_32SceneCode.GDMergeItemObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects2Objects = Hashtable.newFrom({"MergeItem": gdjs.Game_32SceneCode.GDMergeItemObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects2Objects = Hashtable.newFrom({"MergeItem": gdjs.Game_32SceneCode.GDMergeItemObjects2});
gdjs.Game_32SceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.Game_32SceneCode.localVariables[1].getFromIndex(0).getAsNumber() != -1);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMergeItemObjects2 */
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setBoolean(true);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects2Objects, gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber(), gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).getAsNumber(), "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects2[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariables().getFromIndex(2)).setNumber(gdjs.Game_32SceneCode.localVariables[1].getFromIndex(0).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects2[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects2[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getBehavior("Tween").addObjectScaleTween3("mergePop", 1, "easeOutBack", 0.3, false, false);
}
}
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects2Objects = Hashtable.newFrom({"MergeItem": gdjs.Game_32SceneCode.GDMergeItemObjects2});
gdjs.Game_32SceneCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Game_32SceneCode.GDMergeItemObjects1, gdjs.Game_32SceneCode.GDMergeItemObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects2Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariableNumber(gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariables().getFromIndex(1)) == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariableNumber(gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariables().getFromIndex(0)) == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
}
}
if (isConditionTrue_0) {
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setBoolean(true);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDMergeItemObjects1, gdjs.Game_32SceneCode.GDMergeItemObjects2);

{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects2[i].setPosition(gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariables().getFromIndex(1).getAsNumber(),gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariables().getFromIndex(0).getAsNumber());
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMergeItemObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getVariables().getFromIndex(1)).setNumber((gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getPointX("")));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getVariables().getFromIndex(0)).setNumber((gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getPointY("")));
}
}
}

}


};gdjs.Game_32SceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Game_32SceneCode.GDMergeItemObjects1, gdjs.Game_32SceneCode.GDMergeItemObjects2);


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("NextLevel", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects2Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getX() == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getY() == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariableNumber(gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getVariables().getFromIndex(2)) == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(3).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects2Objects) >= 2);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.Game_32SceneCode.localVariables[1].getFromIndex(0).setNumber(runtimeScene.getGame().getVariables().getFromIndex(4).getChild(gdjs.evtTools.common.toString(gdjs.Game_32SceneCode.localVariables[0].getFromIndex(3).getAsNumber())).getChild("nextLevel").getAsNumber());
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList2(runtimeScene);} //End of subevents
}
gdjs.Game_32SceneCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Game_32SceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects2Objects = Hashtable.newFrom({"MergeItem": gdjs.Game_32SceneCode.GDMergeItemObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects3Objects = Hashtable.newFrom({"MergeItem": gdjs.Game_32SceneCode.GDMergeItemObjects3});
gdjs.Game_32SceneCode.eventsList5 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.copyArray(runtimeScene.getObjects("MergeItem"), gdjs.Game_32SceneCode.GDMergeItemObjects3);

elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects3Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects3[i].getX() == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects3[k] = gdjs.Game_32SceneCode.GDMergeItemObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects3[i].getY() == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects3[k] = gdjs.Game_32SceneCode.GDMergeItemObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects3.length = k;
}
}
if (isConditionTrue_0) {
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).setBoolean(true);
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects3Objects = Hashtable.newFrom({"MergeItem": gdjs.Game_32SceneCode.GDMergeItemObjects3});
gdjs.Game_32SceneCode.eventsList6 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.copyArray(runtimeScene.getObjects("MergeItem"), gdjs.Game_32SceneCode.GDMergeItemObjects3);

elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects3Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects3[i].getX() == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects3[k] = gdjs.Game_32SceneCode.GDMergeItemObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects3[i].getY() == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects3[k] = gdjs.Game_32SceneCode.GDMergeItemObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects3.length = k;
}
}
if (isConditionTrue_0) {
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).setBoolean(true);
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects3Objects = Hashtable.newFrom({"MergeItem": gdjs.Game_32SceneCode.GDMergeItemObjects3});
gdjs.Game_32SceneCode.eventsList7 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.copyArray(runtimeScene.getObjects("MergeItem"), gdjs.Game_32SceneCode.GDMergeItemObjects3);

elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects3Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects3[i].getX() == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects3[k] = gdjs.Game_32SceneCode.GDMergeItemObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects3.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects3[i].getY() == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects3[k] = gdjs.Game_32SceneCode.GDMergeItemObjects3[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects3.length = k;
}
}
if (isConditionTrue_0) {
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).setBoolean(true);
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects1Objects = Hashtable.newFrom({"MergeItem": gdjs.Game_32SceneCode.GDMergeItemObjects1});
gdjs.Game_32SceneCode.eventsList8 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.copyArray(runtimeScene.getObjects("MergeItem"), gdjs.Game_32SceneCode.GDMergeItemObjects2);

elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects2Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getX() == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects2.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects2[i].getY() == gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects2[k] = gdjs.Game_32SceneCode.GDMergeItemObjects2[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = k;
}
}
if (isConditionTrue_0) {
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).setBoolean(true);
}
elseEventsChainSatisfied = true;
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDProducerObjects1, gdjs.Game_32SceneCode.GDProducerObjects2);

{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).setNumber((( gdjs.Game_32SceneCode.GDProducerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDProducerObjects2[0].getPointY("")) - 80);
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDProducerObjects1, gdjs.Game_32SceneCode.GDProducerObjects2);

{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setNumber((( gdjs.Game_32SceneCode.GDProducerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDProducerObjects2[0].getPointX("")) - 80);
}
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).setNumber((( gdjs.Game_32SceneCode.GDProducerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDProducerObjects2[0].getPointY("")));
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Game_32SceneCode.GDProducerObjects1, gdjs.Game_32SceneCode.GDProducerObjects2);

{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setNumber((( gdjs.Game_32SceneCode.GDProducerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDProducerObjects2[0].getPointX("")) + 80);
}
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).setNumber((( gdjs.Game_32SceneCode.GDProducerObjects2.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDProducerObjects2[0].getPointY("")));
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.Game_32SceneCode.GDMergeItemObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects1Objects, gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber(), gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber(), "");
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getVariables().getFromIndex(1)).setNumber(gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getVariables().getFromIndex(0)).setNumber(gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber());
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getBehavior("Tween").addObjectScaleTween3("popIn", 1, "easeOutBack", 0.25, false, false);
}
}
}

}

}

};gdjs.Game_32SceneCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Game_32SceneCode.GDMergeItemObjects3, gdjs.Game_32SceneCode.GDMergeItemObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (((gdjs.Game_32SceneCode.GDMergeItemObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Game_32SceneCode.GDMergeItemObjects4[0].getVariables()).getFromIndex(2).getAsNumber() > gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber());
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMergeItemObjects4 */
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).setNumber(((gdjs.Game_32SceneCode.GDMergeItemObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Game_32SceneCode.GDMergeItemObjects4[0].getVariables()).getFromIndex(2).getAsNumber());
}
}

}


};gdjs.Game_32SceneCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("MergeItem"), gdjs.Game_32SceneCode.GDMergeItemObjects2);

for (gdjs.Game_32SceneCode.forEachIndex3 = 0;gdjs.Game_32SceneCode.forEachIndex3 < gdjs.Game_32SceneCode.GDMergeItemObjects2.length;++gdjs.Game_32SceneCode.forEachIndex3) {
gdjs.Game_32SceneCode.GDMergeItemObjects3.length = 0;


gdjs.Game_32SceneCode.forEachTemporary3 = gdjs.Game_32SceneCode.GDMergeItemObjects2[gdjs.Game_32SceneCode.forEachIndex3];
gdjs.Game_32SceneCode.GDMergeItemObjects3.push(gdjs.Game_32SceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Game_32SceneCode.eventsList9(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LevelProgress"), gdjs.Game_32SceneCode.GDLevelProgressObjects1);
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setNumber(gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).getAsNumber() + 1);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLevelProgressObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLevelProgressObjects1[i].getBehavior("Text").setText("Levels: " + gdjs.evtTools.common.toString(gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).getAsNumber()) + " / 100");
}
}
}

}


};gdjs.Game_32SceneCode.eventsList11 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(100);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.runtimeScene.getTime(runtimeScene, "timestamp"));
}
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("deltaMs", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("energyToAdd", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setNumber(gdjs.evtTools.runtimeScene.getTime(runtimeScene, "timestamp") - runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList0(runtimeScene);} //End of subevents
}
gdjs.Game_32SceneCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EnergyBar"), gdjs.Game_32SceneCode.GDEnergyBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("EnergyText"), gdjs.Game_32SceneCode.GDEnergyTextObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnergyTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnergyTextObjects1[i].getBehavior("Text").setText("Energy: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber()));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnergyBarObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnergyBarObjects1[i].SetMaxValue(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber(), null);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDEnergyBarObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDEnergyBarObjects1[i].SetValue(runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber(), null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MergeItem"), gdjs.Game_32SceneCode.GDMergeItemObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getVariables().getFromIndex(1)).setNumber((gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getPointX("")));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMergeItemObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMergeItemObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getVariables().getFromIndex(0)).setNumber((gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getPointY("")));
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MergeItem"), gdjs.Game_32SceneCode.GDMergeItemObjects1);

{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setBoolean(false);
variables._declare("Occupied", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("NewXPosition", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("NewYPosition", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("DroppedLevel", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDMergeItemObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDMergeItemObjects1[i].getBehavior("Draggable").wasJustDropped() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDMergeItemObjects1[k] = gdjs.Game_32SceneCode.GDMergeItemObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDMergeItemObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDMergeItemObjects1 */
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(3).setNumber(((gdjs.Game_32SceneCode.GDMergeItemObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Game_32SceneCode.GDMergeItemObjects1[0].getVariables()).getFromIndex(2).getAsNumber());
}
{gdjs.evtsExt__SnapToGrid__SnapObjectToVirtualGrid.func(runtimeScene, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDMergeItemObjects1Objects, 80, 80, 0, 0, null);
}
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).setNumber((( gdjs.Game_32SceneCode.GDMergeItemObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDMergeItemObjects1[0].getPointX("")));
}
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(2).setNumber((( gdjs.Game_32SceneCode.GDMergeItemObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDMergeItemObjects1[0].getPointY("")));
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList4(runtimeScene);} //End of subevents
}
gdjs.Game_32SceneCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("Producer"), gdjs.Game_32SceneCode.GDProducerObjects1);

elseEventsChainSatisfied = false;
{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("SpawnX", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("SpawnY", variable);
}
{
const variable = new gdjs.Variable();
variable.setBoolean(false);
variables._declare("Found", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDProducerObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDProducerObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDProducerObjects1[k] = gdjs.Game_32SceneCode.GDProducerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDProducerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() > 0);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDProducerObjects1 */
{gdjs.deviceVibration.startVibration(50);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(Math.max(0, runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() - 1));
}
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(0).setNumber((( gdjs.Game_32SceneCode.GDProducerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDProducerObjects1[0].getPointX("")));
}
{gdjs.Game_32SceneCode.localVariables[0].getFromIndex(1).setNumber((( gdjs.Game_32SceneCode.GDProducerObjects1.length === 0 ) ? 0 :gdjs.Game_32SceneCode.GDProducerObjects1[0].getPointY("")) + 80);
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList8(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}
gdjs.Game_32SceneCode.localVariables.pop();

}


{

gdjs.copyArray(runtimeScene.getObjects("Producer"), gdjs.Game_32SceneCode.GDProducerObjects1);

if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDProducerObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDProducerObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDProducerObjects1[k] = gdjs.Game_32SceneCode.GDProducerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDProducerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() <= 0);
}
}
if (!elseEventsChainSatisfied && isConditionTrue_0) {
elseEventsChainSatisfied = true;
}
}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("DiscoveredLevels", variable);
}
{
const variable = new gdjs.Variable();
variable.setNumber(-1);
variables._declare("MaxLevelFound", variable);
}
gdjs.Game_32SceneCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Game_32SceneCode.eventsList10(runtimeScene);} //End of subevents
}
gdjs.Game_32SceneCode.localVariables.pop();

}

}

};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDEnergyTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDEnergyTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDEnergyTextObjects3.length = 0;
gdjs.Game_32SceneCode.GDEnergyTextObjects4.length = 0;
gdjs.Game_32SceneCode.GDEnergyTextObjects5.length = 0;
gdjs.Game_32SceneCode.GDEnergyBarObjects1.length = 0;
gdjs.Game_32SceneCode.GDEnergyBarObjects2.length = 0;
gdjs.Game_32SceneCode.GDEnergyBarObjects3.length = 0;
gdjs.Game_32SceneCode.GDEnergyBarObjects4.length = 0;
gdjs.Game_32SceneCode.GDEnergyBarObjects5.length = 0;
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects4.length = 0;
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects5.length = 0;
gdjs.Game_32SceneCode.GDLevelProgressObjects1.length = 0;
gdjs.Game_32SceneCode.GDLevelProgressObjects2.length = 0;
gdjs.Game_32SceneCode.GDLevelProgressObjects3.length = 0;
gdjs.Game_32SceneCode.GDLevelProgressObjects4.length = 0;
gdjs.Game_32SceneCode.GDLevelProgressObjects5.length = 0;
gdjs.Game_32SceneCode.GDMergeItemObjects1.length = 0;
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = 0;
gdjs.Game_32SceneCode.GDMergeItemObjects3.length = 0;
gdjs.Game_32SceneCode.GDMergeItemObjects4.length = 0;
gdjs.Game_32SceneCode.GDMergeItemObjects5.length = 0;
gdjs.Game_32SceneCode.GDProducerObjects1.length = 0;
gdjs.Game_32SceneCode.GDProducerObjects2.length = 0;
gdjs.Game_32SceneCode.GDProducerObjects3.length = 0;
gdjs.Game_32SceneCode.GDProducerObjects4.length = 0;
gdjs.Game_32SceneCode.GDProducerObjects5.length = 0;

gdjs.Game_32SceneCode.eventsList11(runtimeScene);
gdjs.Game_32SceneCode.GDEnergyTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDEnergyTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDEnergyTextObjects3.length = 0;
gdjs.Game_32SceneCode.GDEnergyTextObjects4.length = 0;
gdjs.Game_32SceneCode.GDEnergyTextObjects5.length = 0;
gdjs.Game_32SceneCode.GDEnergyBarObjects1.length = 0;
gdjs.Game_32SceneCode.GDEnergyBarObjects2.length = 0;
gdjs.Game_32SceneCode.GDEnergyBarObjects3.length = 0;
gdjs.Game_32SceneCode.GDEnergyBarObjects4.length = 0;
gdjs.Game_32SceneCode.GDEnergyBarObjects5.length = 0;
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects3.length = 0;
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects4.length = 0;
gdjs.Game_32SceneCode.GDSoccerFieldBackgroundObjects5.length = 0;
gdjs.Game_32SceneCode.GDLevelProgressObjects1.length = 0;
gdjs.Game_32SceneCode.GDLevelProgressObjects2.length = 0;
gdjs.Game_32SceneCode.GDLevelProgressObjects3.length = 0;
gdjs.Game_32SceneCode.GDLevelProgressObjects4.length = 0;
gdjs.Game_32SceneCode.GDLevelProgressObjects5.length = 0;
gdjs.Game_32SceneCode.GDMergeItemObjects1.length = 0;
gdjs.Game_32SceneCode.GDMergeItemObjects2.length = 0;
gdjs.Game_32SceneCode.GDMergeItemObjects3.length = 0;
gdjs.Game_32SceneCode.GDMergeItemObjects4.length = 0;
gdjs.Game_32SceneCode.GDMergeItemObjects5.length = 0;
gdjs.Game_32SceneCode.GDProducerObjects1.length = 0;
gdjs.Game_32SceneCode.GDProducerObjects2.length = 0;
gdjs.Game_32SceneCode.GDProducerObjects3.length = 0;
gdjs.Game_32SceneCode.GDProducerObjects4.length = 0;
gdjs.Game_32SceneCode.GDProducerObjects5.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
